require 'd_eficiency'

-- Jah existe uma chamada a funcao 'calculate_eficiency()' em d_eficiency.lua!
--calculate_eficiency()

