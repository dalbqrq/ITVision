require 'm_io_util'

function alert_report_list(app, ini, fin, sep, bFile)
	sep = sep or ','
	app = string.gsub(app, "_", " ")

	local time = os.time()
	local log_file = '/usr/local/itvision/model/db/alerts.log'
	local tmp_file = '/tmp/alerts.'..time
	local ofile, omess, oerr
	local s = ''
	local t = ''
	local result = {}

	-- If it's anything else but nil, it will write the result into a file them return the name of this file. 
	if bFile then
		ofile, omess, oerr = assert(io.open(tmp_file, 'w'))
	end

	di = string.sub(ini, 1, 2); mi = string.sub(ini, 4, 5); yi = string.sub(ini, 7, 10)
	df = string.sub(fin, 1, 2); mf = string.sub(fin, 4, 5); yf = string.sub(fin, 7, 10)
	ti = os.time{year=yi, month=mi, day=di, hour=0}
	tf = os.time{year=yf, month=mf, day=df+1, hour=0} -1

	--[[ DEBUG
	print(yi..mi..di)
	print(yf..mf..df)
	print(os.date('%Y-%m-%d %H:%M:%S', ti))
	print(os.date('%Y-%m-%d %H:%M:%S', tf))
	print('app = '..app..' and sep = '..sep) 
	]]--

	local lines = line_reader(log_file)

	for i,v in ipairs(lines) do
		t = fromCSV(v, '|')

		if (app == t[3] or app == '') and ti < tonumber(t[2]) and tf > tonumber(t[2]) then
			table.insert(result, t)
			s = s .. toCSV(t,sep) .. '\n'
			-- [[ DEBUG ]] print(s)

			if bFile then
				ofile:write (s .. '\n')
			end
		end
	end
	
	if bFile then
		ofile:close()
		return tmp_file
	else
		return s, result
	end
end


function alert_report_resume(app, ini, fin)
	app = string.gsub(app, "_", " ")

	local Tt, nu, nw, nd, itu, wti, dti, n, e, a, te, statei, statef, s
	local t = {}
	local r = {}
	local app_list = {}

	s, t = alert_report_list(app, d1, d2)

	if ( app == '' ) then
		app_list = select_applications('')
	else
		app_list = { { name = app } }
	end

	di = string.sub(d1, 1, 2); mi = string.sub(d1, 4, 5); yi = string.sub(d1, 7, 10)
	df = string.sub(d2, 1, 2); mf = string.sub(d2, 4, 5); yf = string.sub(d2, 7, 10)
	ti = os.time{year=yi, month=mi, day=di, hour=0}
	tf = os.time{year=yf, month=mf, day=df+1, hour=0} -1

	--[[ DEBUG
	print('-------------')
	print(app)
	print('-------------')
	print('ini = '..d1..' -> '..ti)
	print('fim = '..d2..' -> '..tf)
	print('-------------')
	showtable(t)
	showtable(app_list)
	print('-------------')
	]]--

	for _, a in ipairs(app_list) do
		Tt = tf - ti

		nu = 0 -- number of up events
		nw = 0 -- number of warning events
		nd = 0 -- number of down events

		uti = ti -- initial uptime
		wti = ti -- initial warningtime
		dti = ti -- initial downtime

		ut = 0 -- total uptime
		wt = 0 -- total warningtime
		dt = 0 -- total downtime

		for n, e in ipairs(t) do
			--showtable(e)
			if ( a.name == e[3] ) then
				te = e[2]
				statef = e[4]
				if ( n == 1 ) then -- TODO: THIS IS A BAD statei INITIALIZATION!!!!
					if ( statef == 'DOWN' ) then
						statei = 'UP'
					else
						statei = 'DOWN'
					end
				end

				if ( statei == 'UP' and statef == 'WARNING' ) then
					wti = te
					ut = ut + (te - uti)
					nw = nw + 1
				elseif ( statei == 'UP' and statef == 'DOWN' ) then
					dti = te
					ut = ut + (te - uti)
					nd = nd + 1
				elseif ( statei == 'WARNING' and statef == 'UP' ) then
					uti = te
					wt = wt + (te - wti)
					nu = nu + 1
				elseif ( statei == 'WARNING' and statef == 'DOWN' ) then
					dti = te
					wt = wt + (te - wti)
					nd = nd + 1
				elseif ( statei == 'DOWN' and statef == 'UP' ) then
					uti = te
					dt = dt + (te - dti)
					nu = nu + 1
				elseif ( statei == 'DOWN' and statef == 'WARNING' ) then
					wti = te
					dt = dt + (te - dti)
					nw = nw + 1
				end

				--[[ DEBUG ]]-- 
				print(statei, statef, ut, dt, wt, te)

				statei = statef
			end
		end
		if ( statef == 'UP' ) then
			ut = ut + (tf - te)
		elseif ( statef == 'WARNING' ) then
			wt = wt + (tf - te)
		elseif ( statef == 'DOWN' ) then
			dt = dt + (tf - te)
		end

		if ( ut == 0 and wt == 0 and dt == 0 ) then 
			ut = Tt
		end

		table.insert(r, { name = a.name, totaltime = Tt, 
			uptime = ut, warntime = wt, downtime = dt, 
			n_up = nu, n_warn = nw, n_down = nd} )

		--showtable(r)
	end

	return table.getn(r), r

end
