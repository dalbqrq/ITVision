
user {
	name = 'ceop',
	password = 'verto'
}

user {
	name = 'admin',
	password = 'otrev'
}

