
daemon_conf = {
	notification_email = '[ITVision - Monitor] - Notificacao PRODERJ!\n\nAplicacao [APPLIC_NAME] encontra-se [STATE]\nData: DATE\n',
	notification_sms   = '[ITVision - Monitor] - Notificacao PRODERJ!\n\nAplicacao [APPLIC_NAME] encontra-se [STATE]\nData: DATE\n',
	max_check_attempts    = 3,
	check_interval        = 1,  -- in minutes
	notification_interval = 30,  -- in minutes
	command_line          = '/bin/mail -s ',
}

