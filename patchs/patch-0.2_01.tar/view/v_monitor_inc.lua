
html_content_type = "Content-type: text/html\r\n\r\n"
text_content_type = "Content-type: text/plain\r\n\r\n"


html_header = [[
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>ITVision</title>
<link href="images/favicon.ico" rel="shortcut icon">
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href="css/tables.css" rel="stylesheet" type="text/css" />
<link href="css/menui.css" rel="stylesheet" type="text/css" />


<!-- ------------------------------------------------ -->
<!-- jQuery -->
<script type="text/javascript" src="js/jquery-1.2.1.min.js"></script>
<!-- required plugins -->
<script type="text/javascript" src="js/date.js"></script>
<!--[if IE]><script type="text/javascript" src="js/jquery.bgiframe.js"></script><![endif]-->
<!-- jquery.datePicker.js -->
<script type="text/javascript" src="js/jquery.datePicker.js"></script>
<!-- CSS is required for datepicker -->
<link href="css/datePicker.css" rel="stylesheet" type="text/css" />
<!-- ------------------------------------------------ -->

<script type="text/javascript">
    $(function() {
		$('.date-pick').datePicker('01/01/2008').val(new Date().asString()).trigger('change');
		$('.date-pick').datePicker({startDate:'01/01/1996'});
	});
</script>
</head>
]]

html_header_refresh = [[
<head>
<META http-equiv="refresh" content="15" target="main">
</head>
]]


html_body = [[

<body>
<a name="top" id="top"></a>
<center>
		<div id="header">
			<a href=http://www.proderj.rj.gov.br>
			<img src="images/logo_proderj1.jpg" alt="Proderj" height=45 border=0 class="logoproderj" />
			</a>
			<!--
			<a href=http://www.proderj.rj.gov.br>
			<img src="images/logo_proderj2.jpg" alt="Proderj" border=0 class="logoverto" />
			</a>
			-->

			<img src="images/logopurple_only.png" alt="Realistic IT Vision" class="logo" />
			<a href=http://www.verto.com.br>

			<img src="images/verto_1.jpg" alt="Verto" border=0 class="logoverto" />
			</a>

			<h1>ITVision - [monitor]</h1>
		</div>
		
		<div id="menuh-container"> 
			<div id="menug">
			<div id="menuh">

			<ul>
				<li	><a href="applic_resume.lp" >home</a>
			</ul>
			<ul>
				<li	><a href="report.lp" >relat&oacute;rios</a>
			</ul>

			<!-- MENU COM SUB-MENUS
			<ul>
				<li	><a href="#" >relat&oacute;rios</a>
				<ul>
					<li><a href="#">eventos</a></li>
					<li><a href="#">uptime</a></li>
				</ul>
			</ul>
			-->

			<ul>
				<li	><a href="help.lp" >ajuda</a>
			</ul>
		
			</div> 
			</div>
		</div>

		<div id="content">
			<div id="mainbar"> 
]]

html_footer = [[
	<div id="footer">
		Sponsored by <a href="http://www.verto.com.br">Verto</a> <!-- &AMP; <A HREF="http://www.atmax.com.br">Atmax</a> --> - version 0.2.1 
			
	</div>
</center>
</body>
</html>
]]

