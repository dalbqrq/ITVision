require 'm_io_util'

function alert_report(app, ini, fin, sep, bFile)
	sep = sep or ','
	app = string.gsub(app, "_", " ")

	local time = os.time()
	local log_file = '/usr/local/itvision/model/db/alerts.log'
	local tmp_file = '/tmp/alerts.'..time
	local ofile, omess, oerr
	local s = ''
	local result = {}

	-- If it's anything else but nil, it will write the resolt into a file em return the name of this file. 
	if bFile then
		ofile, omess, oerr = assert(io.open(tmp_file, 'w'))
	end

	di=string.sub(ini, 1, 2); mi=string.sub(ini, 4, 5); yi=string.sub(ini, 7, 10)
	df=string.sub(fin, 1, 2); mf=string.sub(fin, 4, 5); yf=string.sub(fin, 7, 10)

	ti = os.time{year=yi, month=mi, day=di, hour=0}
	tf = os.time{year=yf, month=mf, day=df+1, hour=0} -1

	--[[ DEBUG
	print(yi..mi..di)
	print(yf..mf..df)
	print(os.date('%Y-%m-%d %H:%M:%S', ti))
	prin-t(os.date('%Y-%m-%d %H:%M:%S', tf))
	]]--

	print('app = '..app..' and sep = '..sep) 

	local lines = line_reader(log_file)

	for i,v in ipairs(lines) do
		t = fromCSV(v, '|')

		if (app == t[3] or app == '') and ti < tonumber(t[2]) and tf > tonumber(t[2]) then
			table.insert(result, t)
			s = s .. toCSV(t,sep) .. '\n'
			-- [[ DEBUG ]] print(s)

			if bFile then
				ofile:write (s .. '\n')
			end
		end
	end
	
	if bFile then
		ofile:close()
		return tmp_file
	else
		return s, result
	end
end


-- [[ DEBUG ]] alert_report('Web_Server', '01/11/2008', '01/11/2008', ',')
--alert_report('', '01/11/2008', '01/11/2008', ',')


